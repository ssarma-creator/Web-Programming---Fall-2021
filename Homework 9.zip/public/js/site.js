let textForm = document.getElementById("textForm");
let textArea = document.getElementById("textArea");
let orderedList = document.getElementById("attempts");
let div = document.getElementById("error");

function checkPalindrome(text) {
  text = text.replace(/[^\w]/g, '').toLowerCase();
  const len = text.length;  
  for (let i = 0; i < len / 2; i++) {  
    if (text[i] !== text[len - 1 - i]) {  
        return false;  
    }  
  }  
  return true;  
}

if (textForm) {
  textForm.addEventListener("submit", (event) => {
    event.preventDefault();

    if (textArea.value) {
      div.hidden = true;
      let isPalindrome = checkPalindrome(textArea.value);
      let li = document.createElement("li");
      if (isPalindrome) {
        li.className = "is-palindrome";
      } else {
        li.className = "not-palindrome";
      }
      li.innerHTML = textArea.value;
      orderedList.appendChild(li);

      textArea.value = "";
      textArea.focus();
    } else {
      div.hidden = false;
      textArea.focus();
    }
  });
}
