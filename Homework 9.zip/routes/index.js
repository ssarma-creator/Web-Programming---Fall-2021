const mainRoutes = require("./main");
const constructorMethod = (app) => {
  app.use("/", mainRoutes);
  app.use("*", (req, res) => {
    res.status(400).render("error", {
      errors: ["URL is invalid"],
      hasErrors: true,
      title: "errors!!",
    });
    return;
  });
};

module.exports = constructorMethod;
