const arrayUtils = require ("./arrayUtils")
const stringUtils = require ("./stringUtils")
const objUtils = require ("./objUtils")
//average tests
try {
    // Should Pass
  
      const averageOne = arrayUtils.average([[3], [4], [5]]);
     console.log('average passed successfully');
  } catch (e) {
      console.error('average failed test case');
 }
 try {
    // Should Fail
       const averageTwo = arrayUtils.average();
       console.error('average did not error');
   } catch (e) {
       console.log('average failed successfully');
 }
 //modeSquared
 try {
    const modetest1 = arrayUtils.modeSquared(([5, 6, 2, 2, 4]));
    console.log('modesquared passed successfully');
 } catch (e) {
    console.error('modesquared failed test case');
 }

 try {
    const modetest2 = arrayUtils.modeSquared(8921);
    console.error('modesquared did not error');
 } catch (e) {
    console.log('modesquared failed successfully');
 }
//medianElement
try {
    const medianElementtest1 = arrayUtils.medianElement([5, 6, 7,7]);
    console.log('medianElement passed successfully');
 } catch (e) {
    console.error('medianElement failed test case');
 }

 try {
    const medianElementtest2 = arrayUtils.medianElement(3456);
    console.error('medianElement did not error');
 } catch (e) {
    console.log('medianElement failed successfully');
 }
//merge
try {
    const mergetest1 = arrayUtils.merge([8, 9, 6], [3, 5, 2]);
    console.log('merge passed successfully');
 } catch (e) {
    console.error('merge failed test case');
 }

 try {
    const mergetest2 = arrayUtils.merge("Hello", 33);
    console.error('merge did not error');
 } catch (e) {
    console.log('merge failed successfully');
 }

 //sortString
 try {
    const sortStringtest1 = stringUtils.sortString("123 Hello World");
    console.log('sortString passed successfully');
 } catch (e) {
    console.error('sortString failed test case');
 }

 try {
    const sortStringtest2 = stringUtils.sortString(123);
    console.error('sortString did not error');
 } catch (e) {
    console.log('sortString failed successfully');
 }
 //replaceChar
 try {
    const replaceChar1 = stringUtils.replaceChar("Sunny",2);
    console.log('replaceChar passed successfully');
 } catch (e) {
    console.error('replaceChar failed test case');
 }

 try {
    const replaceChar2 = stringUtils.replaceChar(12346,"2");
    console.error('replaceChar did not error');
 } catch (e) {
    console.log('replaceChar failed successfully');
 }
 //mashUp
 try {
    const mashUp1 = stringUtils.mashUp("Best", "Sarma","#");
    console.log('mashUp passed successfully');
 } catch (e) {
    console.error('mashUp failed test case');
 }

 try {
    const mashUp2 = stringUtils.mashUp("Sarma");
    console.error('mashUp did not error');
 } catch (e) {
    console.log('mashUp failed successfully');
 }
 //computeObjects
 try {
    const computeObject1 = objUtils.computeObjects([{ x: 0, y: 9, q: 10 }, { x: 2, y: 3}],n => n*2);
    console.log('computeObjects passed successfully');
 } catch (e) {
    console.error('computeObjects failed test case');
 }

 try {
    const computeObject2 = objUtils.computeObjects();
    console.error('computeObjects did not error');
 } catch (e) {
    console.log('computeObjects failed successfully');
 }
//commonKeys
try {
    const commonKeystest1 = objUtils.commonKeys({a: 2, b: 4},{a: 5, b: 4});
    console.log('commonKeys passed successfully');
 } catch (e) {
    console.error('commonKeys failed test case');
 }

 try {
    const commonKeystest2 = objUtils.commonKeys([{}, { x: 2, y: 3}]);
    console.error('commonKeys did not error');
 } catch (e) {
    console.log('commonKeys failed successfully');
 }
 //flipObject
 try {
    const flipObjecttest1  = objUtils.flipObject({ a: 1, b: 3, c: 8 });
    console.log('flipObject passed successfully');
 } catch (e) {
    console.error('flipObject failed test case');
 }

 try {
    const flipObjecttest2 = objUtils.flipObject({}, { x: 2, y: 3});
    console.error('flipObject did not error');
 } catch (e) {
    console.log('flipObject failed successfully');
 }