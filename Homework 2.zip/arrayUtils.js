function isNumber(value){
  return typeof(value)==='number' && Number.isFinite(value);
}
function average(arrays) {
    if (!arrays) {
        throw "An array input is required";
    }
    if (!Array.isArray(arrays)) {
        throw "Input is not an array";
    }
    if (!arrays.length) {
        throw "Input is an empty array.";
    }else{

       let count = sum = 0;
       for (i = 0; i < arrays.length; i++) {

        if (!Array.isArray(arrays[i])) {

            throw "The element in the array is not an array";
        }
        if (!arrays[i].length) {
            throw "The array element is empty";
        }
        for (j = 0; j < arrays[i].length; j++) {
            if (!isNumber(arrays[i][j])) {
                throw "Please provide an array with numbers only";
            }
            sum += arrays[i][j];
            count++;
        }
    }
    return Math.round(sum / count);
}
}

function modeSquared(array) {
    if (!array) {
      throw "Please provide an Array";
    }
    if (!Array.isArray(array)) {
      throw "The input is not an array";
    }
    if (!array.length) {
      throw "The input is an empty array";
    }
    if (array.some(ele => !isNumber(ele))) {
      throw "Please provide an array with numbers ONLY";
    }
    else {
      const frequencyTable = {};
      array.forEach(elem => frequencyTable[elem] = frequencyTable[elem] + 1 || 1);
    
      let modes = [];
      let maxFrequency = 0;
      for (const key in frequencyTable) {
          if (frequencyTable[key] > maxFrequency) {
              modes = [Number(key)];
              maxFrequency = frequencyTable[key];
          }
          else if (frequencyTable[key] === maxFrequency) {
              modes.push(Number(key));
          }
      }
      if (modes.length === Object.keys(frequencyTable).length) modes = [];
      result = 0;
      modes.forEach(elem => result += elem*elem);
      return result;
    }
    }
    function medianElement(array) {
        if (!array) {
      
            throw "Please provide an Array";
        }
        if (!Array.isArray(array)) {
            throw "The input is not an array";
        }
        if (!array.length) {
            throw "The input is an empty array.";
        }
        if (array.some(ele => !isNumber(ele))) {
            throw "Please provide an array with valid numbers ONLY";
        }
        else {
            let map = new Map();
            for(i = array.length; i > 0; i--) {
                map.set(array[i], i);
            }
            array.sort((a, b) => a - b);
            let median;
            let mid = Math.floor(array.length/2);
            if(array.length % 2 == 0) {
                median = (array[mid] + array[mid-1])/2;
            } else {
                median = array[mid];
            }
            let index = map.get(array[mid]);
            let newObj = {
                [median]: index
            }
            return newObj;
        }
      }
      function merge(arrayOne, arrayTwo) {
        if (!arrayOne) {
            throw "arrayOne parameter is missing!";
        }
        if (!arrayTwo) {
            throw "arrayTwo parameter is missing!";
        }
        if (!Array.isArray(arrayOne)) {
            throw "arrayOne input is not an array!";
        }
        if (!Array.isArray(arrayTwo)) {
            throw "arrayTwo input is not an array!";
        }
        if (arrayOne.some(ele => typeof(ele) !== 'string' && !isNumber(ele)))
        {
        throw "Please provide an array with Numbers/characters ONLY";
        }
        if (arrayTwo.some(ele => typeof(ele) !== 'string' && !isNumber(ele)))
        {
        throw "Please provide an array with Numbers/characters ONLY";
        }
        
        ar = arrayOne.concat(arrayTwo);
        ar.sort();
        let newArray = ar.filter((ch) => !isNaN(parseInt(ch)));
        for (var i = 0; i < ar.length; i++) {
            if (ar[i] === parseInt(ar[i], 10)) {
                delete ar[i]
            }
        }
        resultArray = ar.concat(newArray)
        return resultArray.filter(n => n)
    
  
  }
      
      

module.exports = {
    average,
    modeSquared,
    medianElement,
    merge
}