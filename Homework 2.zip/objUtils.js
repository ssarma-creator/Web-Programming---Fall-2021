function  isObject(obj){
    return typeof(obj) ==='object' && obj !== null && !Array.isArray(obj);
}
function isNumber(value){
    return typeof(value) === 'number' && Number.isFinite(value);
}
function computeObjects(objects, func) {
    const returnObj = {};
    if(!objects){
        throw "Please provide an array of objects"
    }
    if(!Array.isArray(objects)){
        throw "Input parameter is not an array!"
    }
    if(!objects.every(elem => isObject(elem))){
        throw "Every element in the Array has to be an object" 
    }
    if(objects.some(ele => JSON.stringify(ele) === '{}')){
        throw "Any of the objects cannot be an empty object"
    }
    if(objects.length < 1){
        throw "At least 1 elements (objects) in the array must be present"
    }
    if (typeof func != 'function') {
        throw "The second parameter in the input has to be a function";
    }
    for (i = 0; i < objects.length; i++) {
        if (typeof (objects[i]) != 'object')
            throw "Not an object";
        if (Object.keys(objects[i]).length === 0)
            throw "Empty object";
        if (Object.values(objects[i]).some(ele => !isNumber(ele))) {
            throw "Value is not a number";
        }
        for (a in objects[i]) {
            if (!(a in returnObj)) {
                returnObj[a] = 0;
            }
            returnObj[a] = returnObj[a] + func(objects[i][a]);
        }
    }
    return returnObj;
}

function commonKeys(obj1, obj2) {
  if(!obj1 && !obj2)
  throw "The two parameters are missing";
  if(!obj1)
  throw "The obj1 parameter is missing!";
  if(!obj2)
  throw "The obj2 parameter is missing!";
  if(!isObject(obj1) && !isObject(obj2))
  throw "The parameters are not objects";
  if(!isObject(obj1))
  throw "The obj1 is not an Object.";
  if(!isObject(obj2))
  throw "The obj2 is not an Object.";  
else{
  let commonObj = {};
  for (let key1 in obj1) {

    for (let key2 in obj2) {

      if (key1 === key2) {

        if (typeof obj1[key1] == "object" && typeof obj2[key2] == "object") {

          for (let key3 in obj1[key1]) {

            for (let key4 in obj2[key2]) {

              if (obj1[key3] === obj2[key4]) {

                obje = {};
                obje[key3] = obj1[key1][key3];
                commonObj[key2] = obje;
              }
            }
          }
        } else {
          if (obj1[key1] === obj2[key2]) {
            commonObj[key1] = obj1[key2];
            }
          }
       }
     }
  }
  return commonObj;
 }
}
  function flipObject(object) {
    if (!object){
      throw "Please provide an object!";
    }
    if (!isObject(object)){
      throw "The input parameter is not an object.";
    }
    if (JSON.stringify(object) === '{}'){
      throw "Object is empty"
    }else{
    let newObj = {};
    for (var key in object) {
      if (object.hasOwnProperty(key)) {
          if(typeof object[key] === 'object'){
            let out = flipObject(object[key])
            newObj[key] = out
          }else{
            newObj[object[key]] = key
          }
      }
    }
    return newObj;
  }
}
  
module.exports = {
  computeObjects,
  commonKeys,
  flipObject
}