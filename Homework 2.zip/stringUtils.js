function sortString(string){
    if(!string){
           "An input string is required."
       }
       if(string.length<=0)
       {
           throw "Length of the string is 0"
       }
       if(typeof(string) !== 'string')
       {
           throw "Please provide a string."
       }  
       if(string.trim() == "")
       {
           throw "The string entered has just empty spaces.";
       }else{
       var arr = string.split('');
       let numbersArray = arr.filter(e => parseInt(e));
       let numbersArraySort = numbersArray.sort();
       
       let charArray = arr.filter(e => e.match(/[a-z]/i));
       let charArraySort = charArray.sort();
       
       let spaceArray = arr.filter(e => e.match(/[ ]/i));
       
       let specialCharArray = arr.filter(e => e.match(/[^\w\s]/gi));
       let specialCharArraySort = specialCharArray.sort();
    
       return (((charArraySort.concat(numbersArraySort)).concat(specialCharArraySort)).concat(spaceArray)).join('');
    }
}

function replaceChar(string, idx) {
    if (!string) {
        throw "Parameter Missing. You must provide a parameter."
    }
    if (string.length <= 0) {
        throw "The string entered has a length Zero.(Empty String) Please enter a valid string."
    }
    if (typeof (string) !== 'string') {
        throw "Parameter is not a String. You must provide a string."
    }
    if (string.trim() == "") {
        throw "The string entered has just empty spaces.";
    }
    if (idx.length <= 0 && idx.length >= string.length - 2) {
        throw "The idx number is out of bounds"
    }
    if (!Number.isInteger(idx)) {
        throw "idx is not an integer. Please provide an Integer.";
    }
  
    let arr = string.split('');
    let first = arr[idx-1];
    let second = arr[idx+1];
    let flag = true;
    for (let i = idx+1; i < arr.length; i++) {
        if(arr[idx] === arr[i]){
            arr[i] = flag==true ? first :second;
            if(flag == true){ flag = false}else{flag = true}
        }
    }
    return arr.join('');
  
  }


function mashUp(string1, string2, char){
    {
      if(!string1 && !string2 && !char)
     {
         throw " Please provide three parameters of type String."
     }
    
     else if(typeof(string1) !== 'string')
     {
         throw "string1 Parameter is not a String"
     }
     if(typeof(string2) !== 'string')
     {
         throw "string2 Parameter is not a String"
     }
     if(typeof(char) !== 'string')
     {
         throw "char Parameter is not a String."
     }
     if(string1.trim() == "" && string2.trim() == "" && char.trim() == "")
     {
         throw "strings has just empty spaces!";
     }
     if(string1.trim() == "")
     {
         throw "The string1 entered has just empty spaces.";
     }
     if(string2.trim() == "")
     {
         throw "The string2 entered has just empty spaces.";
     }
     if(char.trim() == "")
     {
         throw "The char entered has just empty spaces.";
     }
     else{
      let lenOfString1 = string1.length;
      let lenOfString2= string2.length;
      let res = "";
      
      if(lenOfString1 > lenOfString2)
      {
          for(let i=0; i<lenOfString1-lenOfString2; ++i)
          {
              string2 = string2 + char;
          }
      }
      else if(lenOfString2 > lenOfString1)
      {
          for(let i=0; i<lenOfString2-lenOfString1; ++i)
          {
              string1 = string1 + char;
          }
      }
      
      for(let i=0; i<string1.length;++i)
      {
          res = res+string1.charAt(i);
          res = res+string2.charAt(i);
      }
      return res;
  }
  }
  }
  module.exports = {
    sortString,
    replaceChar,
    mashUp
}