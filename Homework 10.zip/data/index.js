const userData = require('./users');

module.exports = {
  users: userData
};