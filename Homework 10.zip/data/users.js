const mongoCollections = require('./../config/mongoCollections');
const users = mongoCollections.users;
const bcrypt = require('bcrypt');
const saltRounds = 10;
let { ObjectId, Db } = require('mongodb');



async function createUser(username, password){
    if(!username || !password) throw "All fields to have valid values";
    if(typeof(username) !=='string' || typeof(password) !=='string')  throw "All the parameters has to be string";
    if(username.trim().length == 0 || password.trim().length == 0) throw "All the parameters has to be string";
    if(!username.match(/^[A-Za-z0-9]+$/)) throw "The username has to be a alphanumeric character";
    if(username.length<4) throw "Username should be atleast 4 characters long";
    if(password.length<6) throw "Password should be atleast 6 characters long";
    
    const usersCollection = await users();
    let duplicateUser = await usersCollection.findOne({username: username.toLowerCase()});
    if(duplicateUser !== null) throw "There is already a user with that username";


    const hashedPassword = bcrypt.hashSync(password, saltRounds);

    
    

    let newUser = {
        username: username.toLowerCase(),
        password: hashedPassword

    }
    const insertDetails = await usersCollection.insertOne(newUser);
        if(insertDetails.insertedCount === 0) throw "Could not add user"
        
        return {userInserted: true};


}

async function checkUser(username, password){
    if(!username || !password) throw "All fields to have valid values";
    if(typeof(username) !=='string' || typeof(password) !=='string')  throw "All the parameters has to be string";
    if(username.trim().length == 0 || password.trim().length == 0) throw "All the parameters has to be string";
    if(!username.match(/^[A-Za-z0-9]+$/)) throw "Incorrect username or password";
    if(username.length<4) throw "Incorrect username or password";
    if(password.length<6) throw "Incorrect username or password";

    const usersCollection = await users();
    let user = await usersCollection.findOne({username : username.toLowerCase()})
    if(!user || !user._id) throw "Either the username or password is invalid"
    let mat = await bcrypt.compare(password, user.password);
    if(!mat) throw "Either the username or password is invalid"
    return {authenticated: true}

}
module.exports={
    createUser,
    checkUser
}