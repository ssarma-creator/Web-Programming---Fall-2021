const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const data = require('../data');
const usersData = data.users;

router.get('/', async (req, res) => {
    try {
        if(req.session.user)
            return res.redirect('/private')
        else
            res.render('posts/login', { title: "Login Screen" })
    } catch (e) {
        res.status(404).json({
            error: 'Not found'
        });
    }
});


module.exports = router;