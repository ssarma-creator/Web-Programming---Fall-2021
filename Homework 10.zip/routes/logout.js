const express = require('express');
const router = express.Router();
const data = require('../data');
//const usersData = data.users;

router.get('/logout', async (req, res) => {

    res.clearCookie('session')
    req.session.destroy();
    res.send('Logged Out');
});

module.exports = router;