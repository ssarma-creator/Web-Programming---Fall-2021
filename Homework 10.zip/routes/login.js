const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const data = require('../data');
const usersData = data.users;

router.post('/', async (req, res) => {
    try {

        if (!req.body.username || req.body.username.trim() == "") {
            res.status(400);
            res.render('posts/login', {
                error: "Please pass the username value!",
                title: "Login",
                notFound: false
            })
            return;
        }

        if (typeof req.body.username !== "string") {
            res.status(400);
            res.render('posts/login', {
                error: "username value must be string only",
                title: "Login",
                notFound: false
            })
            return;
        }
        if(req.body.username.length<4 || !req.body.username.match(/^[A-Za-z0-9]+$/ )){
            res.status(400);
            res.render('posts/login', {
                error: "Incorrect username or password",
                title: "Login",
                notFound: false
            })
            return;
        }
        if (!req.body.password || req.body.password.trim() == "") {
            res.status(400);
            res.render('posts/login', {
                error: "Please pass the password value!",
                title: "Login",
                notFound: false
            })
            return;
        }

        if (typeof req.body.password !== "string") {
            res.status(400);
            res.render('posts/login', {
                error: "Password value must be string only",
                title: "Login",
                notFound: false
            })
            return;
        }
        if(req.body.password.length<6){
            res.status(400);
            res.render('posts/login', {
                error: "Incorrect username or password",
                title: "Login",
                notFound: false
            })
            return;
        }

        const { username, password } = req.body;
        const userSearchedData = await usersData.checkUser(username, password)
        if(!userSearchedData.authenticated || userSearchedData.authenticated!=true){
            res.status(400);
            res.render('posts/login', { title: "Login Screen", error: "Please provide a valid username and/or password." })
            return;
        }
        
        else{
            req.session.user = { userName:username}
            res.redirect('/private');
        }
    } catch (e) {
        res.status(500);
        res.render('posts/login', { title: "Login Screen", error: e })
        return;
    }
});
module.exports = router;