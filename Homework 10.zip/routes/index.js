const mainRoutes = require('./main');
const signUP = require('./signup');
const loGin = require('./login');
const priVate = require('./private');
const logOut = require('./logout')

const constructorMethod = (app) => {
  app.use('/', mainRoutes);
  app.use('/signup',signUP);
  app.use('/login',loGin);
  app.use('/private',priVate);
  app.use('/logout',logOut);

  app.use('*', (req, res) => {
    res.redirect('/');
  });
};

module.exports = constructorMethod;