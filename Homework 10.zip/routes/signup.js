const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const data = require('../data');
const usersData = data.users;

router.get('/', async (req, res) => {
    try {
        if(req.session.user)
            return res.redirect('/private')
        else
            res.render('posts/signup', { title: "SignUP Screen" })
    } catch (e) {
        res.status(404).json({
            error: 'Not found'
        });
    }
});

router.post('/', async (req, res) => {
    try {

        if (!req.body.username || req.body.username.trim() == "") {
            res.status(400);
            res.render('posts/signup', {
                error: "Please pass the username value!",
                title: "SignUp",
                notFound: false
            })
            return;
        }

        if (typeof req.body.username !== "string") {
            res.status(400);
            res.render('posts/signup', {
                error: "username value must be string only",
                title: "SignUp",
                notFound: false
            })
            return;
        }
        if(req.body.username.length<4 || !req.body.username.match(/^[A-Za-z0-9]+$/ )){
            res.status(400);
            res.render('posts/signup', {
                error: "username should be at least 4 characters long and has to be alphanumeric",
                title: "SignUp",
                notFound: false
            })
            return;
        }
        if (!req.body.password || req.body.password.trim() == "") {
            res.status(400);
            res.render('posts/signup', {
                error: "Please pass the password value!",
                title: "SignUp",
                notFound: false
            })
            return;
        }

        if (typeof req.body.password !== "string") {
            res.status(400);
            res.render('posts/signup', {
                error: "Password value must be string only",
                title: "SignUp",
                notFound: false
            })
            return;
        }
        if(req.body.password.length<6){
            res.status(400);
            res.render('posts/signup', {
                error: "Password should be at least 6 characters long",
                title: "SignUp",
                notFound: false
            })
            return;
        }

        const { username, password } = req.body;
   
        
        let user = await usersData.createUser(username, password);
        if (user.userInserted) {
            req.session.user = { userName: username}
            res.redirect('/private');
        } else {
            res.status(500);
            res.render('posts/signup', { title: "Signup", error: "Internal Server Error" })
            return;
        }
    } catch (e) {
        
        res.status(500);
        res.render('posts/signup', { title: "Signup", error: e })
        return;
    }
});
module.exports = router;