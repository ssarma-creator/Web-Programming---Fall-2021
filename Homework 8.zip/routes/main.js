const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
    try {
        res.render('posts/index', { title: "Character Finder" })
    } catch (e) {
        res.status(404).json({
            error: 'Not found'
        });
    }
});

module.exports = router;