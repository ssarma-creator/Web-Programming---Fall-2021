const express = require('express');
const router = express.Router();
const data = require("../data");
const characters = data.characters;

router.post('/', async (req, res) => {
    try {
        if (!req.body.searchTerm || req.body.searchTerm.trim() == "") {
            res.status(400);
            res.render('posts/search', { error: "Search value should not be blank", title: "Character Found", verifySearchTerm: req.body.searchTerm, noResult: false })
            return;
        }

        if (typeof req.body.searchTerm !== "string") {
            res.status(400);
            res.render('posts/search', { error: "Search value should be in String only", title: "Character Found", verifySearchTerm: req.body.searchTerm, noResult: false })
            return;
        }

        const searchByTerm = await characters.getSearchResult(req.body.searchTerm);
        res.render('posts/search', { results: searchByTerm, error: false, title: "Character Found", verifySearchTerm: req.body.searchTerm, noResult: (searchByTerm.length == 0) ? true : false });
    } catch (e) {
        if (e.message) {
            res.status(400);
            res.render('posts/search', { error: e.message, title: "Character Found", verifySearchTerm: req.body.searchTerm, noResult: false });
            return;
        }
        res.status(500);
        res.render('posts/search', { error: e, title: "Character Found", verifySearchTerm: req.body.searchTerm, noResult: false });
        return;
    }
});

module.exports = router;