const express = require('express');
const router = express.Router();
const data = require("../data");
const charactersData = data.characters;

router.get('/:id', async (req, res) => {
    try {
        if (!Number.isInteger(Number(req.params.id))) {
            res.status(404).json({ error: "ID should be integer only" })
            return;
        }

        if (Number(req.params.id) < 1) {
            res.status(404).json({ error: "ID should not be zero" })
            return;
        }
        let characterByID = await charactersData.getCharacterByID(req.params.id);
        res.render('posts/characters', { result: characterByID[0], title: characterByID.name, noResult: true });
    } catch (e) {
        if (e.message) {
            res.status(404);
            res.render('posts/characters', { error: "No characters found", title: "No characters found" });
            return;
        }
    }
});

module.exports = router;
