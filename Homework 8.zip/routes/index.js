const mainRoutes = require('./main');
const characterRoutes = require('./characters');
const searchRoutes = require('./search');

const constructorMethod = (app) => {
  app.use('/', mainRoutes);
  app.use('/characters', characterRoutes);
  app.use('/search', searchRoutes);

  app.use('*', (req, res) => {
    res.status(404).json({ error: 'Not found' });
  });
};

module.exports = constructorMethod;