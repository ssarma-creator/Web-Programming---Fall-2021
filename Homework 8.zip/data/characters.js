const axios = require("axios")
const md5 = require('blueimp-md5');
const publickey = 'e4fb75780cc002571c5fff7ebb876f84';
const privatekey = 'a7f18bcc0c4bb6ab77728e0a504c4dd12382e157';
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = 'https://gateway.marvel.com:443/v1/public/characters';
const  url = baseUrl + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
async function getCharacterByID(id) {
    let  characterIDURL = baseUrl + '/' + id + '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
    
    
    let characterIDData = await axios.get(characterIDURL)
    if (characterIDData.data.data.results) return characterIDData.data.data.results
    else    throw 'There is no character with that ID.'
    
}
async function getSearch(searchTerm) {
    let  searchURL = baseUrl + '?nameStartsWith=' + searchTerm + '&ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
    const { data } = await axios.get(searchURL)
    return data
}

const getSearchResult = async function getSearchResult(searchTerm) {
    if (!searchTerm || searchTerm.trim() == "") throw 'Search value cannot be left blank.';
    if (typeof searchTerm !== 'string') throw 'Search value must be in string format only.';
    data = await getSearch(searchTerm);
    if (!data.data.results > 0) return []
    return data.data.results;
}

module.exports = {
    getCharacterByID,
    getSearchResult
}