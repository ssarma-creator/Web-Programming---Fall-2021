const characterData = require("./characters");


module.exports = {
  characters: characterData,
};