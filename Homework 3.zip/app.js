const people = require("./people");
const stocks = require("./stocks");
async function main(){
    try{
        const peopledata = await people.getPeople();
        console.log (peopledata);
    }catch(e){
        console.log (e);
    }
    //getPersonById
    try{
        const getPersonById = await people.getPersonById("7989fa5e-8f3f-458d-ad58-23c8d9ef5a10");
        console.log (getPersonById);
    }catch(e){
        console.log (e);
    }
    try{
        const getPersonById = await people.getPersonById(" ");
        console.log (getPersonById);
    }catch(e){
        console.log (e);
    }
    try{
        const getPersonById = await people.getPersonById(1001);
        console.log (getPersonById);
    }catch(e){
        console.log (e);
    }
    try{
        const getPersonById = await people.getPersonById();
        console.log (getPersonById);
    }catch(e){
        console.log (e);
    }
    // sameStreet(streetName, streetSuffix)
    try{
        const sameStreet = await people.sameStreet("Sutherland", "Point");
        console.log (sameStreet);
    }catch(e){
        console.log (e);
    }
    try{
        const sameStreet = await people.sameStreet("CO");
        console.log (sameStreet);
    }catch(e){
        console.log (e);
    }
    try{
        const sameStreet = await people.sameStreet(1);
        console.log (sameStreet);
    }catch(e){
        console.log (e);
    }
    try{
        const sameStreet = await people.sameStreet(" "," ");
        console.log (sameStreet);
    }catch(e){
        console.log (e);
    }
    try{
        const sameStreet = await people.sameStreet();
        console.log (sameStreet);
    }catch(e){
        console.log (e);
    }
    //manipulateSsn
    try{
        const manipulateSsn = await people.manipulateSsn();
        console.log (manipulateSsn);
    }catch(e){
        console.log (e);
    // sameBirthday
    try{
        const sameBirthday = await people.sameBirthday(09, 25);
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    }
    try{
        const sameBirthday = await people.sameBirthday(9, 25);
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    try{
        const sameBirthday = await people.sameBirthday("09", "25");
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    try{
        const sameBirthday = await people.sameBirthday(09, 31);
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    try{
        const sameBirthday = await people.sameBirthday(13, 25);
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    try{
        const sameBirthday = await people.sameBirthday(02, 29);
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    try{
        const sameBirthday = await people.sameBirthday();
        console.log (sameBirthday);
    }catch(e){
        console.log (e);
    }
    


    //stocks
    //listShareholders()
    try{
        const listShareholders = await stocks.listShareholders();
        console.log (listShareholders);
    }catch(e){
        console.log (e);
    }
 //topShareholder
    try{
        const topShareholder = await stocks.topShareholder('Aeglea BioTherapeutics, Inc.');
        console.log (topShareholder);
    }catch(e){
        console.log (e);
    }
    try{
        const topShareholder = await stocks.topShareholder('Nuveen Floating Rate Income Fund');
        console.log (topShareholder);
    }catch(e){
        console.log (e);
    }
    try{
        const topShareholder = await stocks.topShareholder('Powell Industries, Inc.');
        console.log (topShareholder);
    }catch(e){
        console.log (e);
    }
    try{
        const topShareholder = await stocks.topShareholder(43);
        console.log (topShareholder);
    }catch(e){
        console.log (e);
    }
    
    //listStocks
    try{ 
        const listStocks = await stocks.listStocks("Grenville", "Pawelke");
        console.log (listStocks);
    }catch(e){
        console.log (e);
    }
    try{
        const listStocks = await stocks.listStocks();
        console.log (listStocks);
    }catch(e){
        console.log (e);
    }
    try{
        const listStocks = await stocks.listStocks("   ","    ");
        console.log (listStocks);
    }catch(e){
        console.log (e);
    }
    //getStockById(id)
    try{
            const getStockById = await stocks.getStockById("f652f797-7ca0-4382-befb-2ab8be914ff0");
            console.log (getStockById);
    }catch(e){
        console.log (e);
    }
    try{
            const getStockById = await stocks.getStockById(-1);
            console.log (getStockById);
    }catch(e){
        console.log (e);
    }
    try{
            const getStockById = await stocks.getStockById();
            console.log (getStockById);
    }catch(e){
        console.log (e);
    }
}

//call main
main();