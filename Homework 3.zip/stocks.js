const axios = require('axios');
const people = require("./people");

async function getStocks(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/8c363d85e61863ac044097c0d199dbcc/raw/7d79752a9342ac97e4953bce23db0388a39642bf/stocks.json')
    
    return data 
    
  }
async function getPeople(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/a1196cbf008e85a8e808dc60d4db7261/raw/9fd0d1a4d7846b19e52ab3551339c5b0b37cac71/people.json')
    return data 
  }

  async function listShareholders()
  {
    const getStock = await getStocks();
    const getPeopl = await people.getPeople();
    let returnArray = [];
    for(let i =0;i<getStock.length;i++){
       let stockObject = {};
       stockObject.id = getStock[i].id;
       stockObject.stock_name = getStock[i].stock_name;
       let userIdlist = getStock[i].shareholders;
       let userIdArray = []
       for(let j =0;j<userIdlist.length;j++){
        const tempobj = getPeopl.find(ele => ele.id == userIdlist[j].userId);
        let filteredobj ={}
        filteredobj.first_name = tempobj.first_name;
        filteredobj.last_name = tempobj.last_name;
        filteredobj.number_of_shares=userIdlist[j].number_of_shares;
        userIdArray.push(filteredobj);
      };
      
    stockObject.shareholders = (userIdArray);
    
    returnArray.push(stockObject)
}

return JSON.stringify(returnArray);
}
//-----------------------------------------------------------------------------

async function topShareholder(stockName) {
    if (!stockName) throw "Parameter missing! Please enter a  valid stock name";
    if (typeof (stockName) !== 'string') throw "Parameter is not a string! Please enter a  valid stock name in form of string";
    if (stockName.trim() == "") throw "The parameter is just empty spaces"
    const getStock = await getStocks();
    let stockRes = getStock.find(ele => ele.stock_name == stockName);
    if(!stockRes) return `${stockName} is not available.`;

    let mostSharePerson = (stockRes.shareholders.sort((a, b) => (a.number_of_shares > b.number_of_shares) ? 1 : -1))[stockRes.shareholders.length - 1]
    if(!mostSharePerson || mostSharePerson.length<1) return `${stockName} currently has no shareholders.`;
    let getPerson = await people.getPersonById(mostSharePerson.userId);
    return `With ${mostSharePerson.number_of_shares} shares in ${stockName}, ${getPerson.first_name}  ${getPerson.last_name} is the top shareholder`
  
  }


//------------------------------------------------------------
    
  

async function listStocks(firstName, lastName) {
    if (!firstName) throw "Parameter missing! Please enter a  valid stock name";
    if (typeof (firstName) !== 'string') throw "Parameter is not a string! Please enter a  valid stock name in form of string";
    if (!lastName) throw "Parameter missing! Please enter a  valid stock name";
    if (typeof (lastName) !== 'string') throw "Parameter is not a string! Please enter a  valid stock name in form of string";
    if (firstName.trim() == "") throw "The parameter is just empty spaces";
    if (lastName.trim() == "") throw "The parameter is just empty spaces";
    const getStock = await getStocks();

    
    const getPeopl = await getPeople();

    let person = getPeopl.find(ele => (ele.first_name === firstName && ele.last_name === lastName));
    if (person == undefined) throw "Person doesnt exist";
    
    let result = []

    getStock.forEach(element => {
        element.shareholders.forEach(share => {
            if (share.userId === person.id) {
                count = {};
                count.stock_name = element.stock_name;
                count.number_of_shares = share.number_of_shares;
                result.push(count);
            }
        })
    });
    return result
}
//----------------------------------------------------------------------------
async function getStockById(id) {
   
    if (!id) throw "Parameter missing! Please enter a  valid Parameter";
    if (typeof (id) != "string") throw "The parameter must be a string";
    if (id.trim() == "") throw "The parameter is just empty spaces";
    if (id != id.toLowerCase()) throw "The id is case sensitive";

    
    const getStock = await getStocks();
    let res = getStock.find(ele => ele.id == id);
    if (!res) {
        throw "Stock not found";
    } else {
        return res;
    }
}
        
    
  //----------------------------------------------------------------
  module.exports={
    listShareholders,
    topShareholder,
    listStocks,
    getStockById
  }
  