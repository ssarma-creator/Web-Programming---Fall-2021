const axios = require('axios');

async function getPeople(){
    const { data } = await axios.get('https://gist.githubusercontent.com/graffixnyc/a1196cbf008e85a8e808dc60d4db7261/raw/9fd0d1a4d7846b19e52ab3551339c5b0b37cac71/people.json')
 
    return data;
  } 
async function getPersonById(id) {
    
    if (!id) throw "Parameter missing! Please enter a  valid Parameter";
    if (typeof (id) != "string") throw "The parameter must be a string";
    if (id.trim() == "") throw "The parameter is just empty spaces";
    if (id != id.toLowerCase()) throw "The id is case sensitive";

   
    const getPeopl = await getPeople();
    let res = getPeopl.find(ele => ele.id == id);
    if (!res) {
        throw "Person not found";
    } else {
        return res;
    }
}

//------------------------------------------------------------------------------
async function sameStreet(streetName, streetSuffix) {
    if (!streetName && !streetSuffix) throw "Parameter missing. Please enter a valid parameter";
    if (typeof (streetName) != 'string') throw "Please enter a valid parameter";
    if (typeof (streetSuffix) != 'string') throw "Please enter a valid parameter";
    if (streetName.trim() === "") throw "The input just contains just white spaces";
    if (streetSuffix.trim() === "") throw "The input just contains just white spaces"


    const getPeopl = await getPeople();

    

    st = getPeopl.filter(ele =>
    (((ele.address.home.street_name.toUpperCase() === streetName.toUpperCase() && ele.address.home.street_suffix.toUpperCase() === streetSuffix.toUpperCase()))
        || (ele.address.work.street_name.toUpperCase() === streetName.toUpperCase() && ele.address.work.street_suffix.toUpperCase() === streetSuffix.toUpperCase())));

  
    if (st.length < 2) throw " there are not at least two people that live or work on the input street names"
   
    return st;


}
  
///-----------------------------------------------------------------------------------
async function manipulateSsn() {
    let getPeopl = await getPeople();
      for (let i = 0; i < getPeopl.length; i++) {
        getPeopl[i].ssn = Number(getPeopl[i].ssn.replace(/-/g, '').split("").sort().join(""));
      
      }
    
      let getPeoplSort = getPeopl.sort((a, b) => (a.ssn > b.ssn) ? 1 : -1);
      let first = getPeoplSort[getPeopl.length-1];
      let last = getPeoplSort[0];
      let arrAvg = getPeoplSort.reduce(function (previousValue, currentValue) {  return Number(previousValue) + Number(currentValue.ssn) }, 0) ;
      let arrAverage = Math.floor(arrAvg/getPeoplSort.length);
      return {highest : {firstName : first.first_name, lastName : first.last_name}, 
      lowest : {firstName : last.first_name, lastName : last.last_name},
      average : arrAverage
      }
  }
  
//-----------------------------------------------------
async function sameBirthday(month, day) {
    

    if (!month && !day) throw "Parameter missing. Please enter a valid parameter";

    if (typeof (month) == 'string') {
        if (month.trim() === "" || isNaN(month)) throw "Invalid month provided"
        month = parseInt(month)
    }

    if (typeof (day) == 'string') {
        if (day.trim() === "" || isNaN(day)) throw "Invalid day provided"
        day = parseInt(day)
    }

    if (month < 1 || month > 12) throw "Invalid month provided"

    let daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    for (let i = 0; i < daysInMonth.length; i++) {
        if (month == i && day > daysInMonth[i]) {
            throw "Invalid number of days provided for the month"
        }
    }
    let resArray = [];
    let getPeopl = await getPeople();
    for (let i = 0; i < getPeopl.length; i++) {
        let date_of_birth = getPeopl[i].date_of_birth.split("/");
        if (Number(date_of_birth[0]) == Number(month) && Number(date_of_birth[1]) == Number(day)) {
            resArray.push(getPeopl[i].first_name + " " + getPeopl[i].last_name);
        }
    }
    if (resArray == []) throw "No people with the provided birthday"
    return resArray;
}
   
//------------------------------------------------------
  
module.exports =
{
  getPeople,
  getPersonById,
  sameStreet,
  manipulateSsn,
  sameBirthday
}


