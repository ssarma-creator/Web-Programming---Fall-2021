const mongoCollections = require('./../config/mongoCollections');
const restaurants = mongoCollections.restaurants;
const restaurantsObj = require('./restaurants');
let { ObjectId } = require('mongodb');

async function create(restaurantId, title, reviewer, rating, dateOfReview, review) {
    if (!title || !reviewer || !rating || !dateOfReview || !review) throw "Please provide an Id to search"
    if (typeof title !== "string" || typeof reviewer !== "string" || typeof rating !== "number" || typeof dateOfReview !== "string") throw "All the fields must be provided in string and rating in number"
    if (title.trim().length == 0 || reviewer.trim().length == 0 || dateOfReview.trim().length == 0 || review.trim().length == 0) throw "All parameters must not contain blank space."
    if (rating < 1 || rating > 5) throw "The rating should be between 1 to 5 only."
    if (await verifyReviewDate(dateOfReview) !== 1) throw "The dateOfReview should be in MM/DD/YYYY format."
    const restaurantCollection = await restaurants();
    let restaurantID = { _id: new ObjectId(restaurantId) };
    let restaurantsValue = { $push: { reviews: { _id: ObjectId(), title, reviewer, rating, dateOfReview, review } } };
    let insertReviewIntoDB = await restaurantCollection.updateOne(restaurantID, restaurantsValue);
    if (insertReviewIntoDB.modifiedCount === 0) throw "Unable to add a review for the given restaurant ID."
    var reviews_ = await getAll(restaurantId)
    let count = 0
    for (let review_ of reviews_.reviews) {
        count = count + review_.rating
    }
    await restaurantCollection.updateOne({ _id: new ObjectId(restaurantId) }, { $set: { overallRating: Number((count / (reviews_.reviews).length).toFixed(2))}});
    if (insertReviewIntoDB.modifiedCount === 1)
        return await restaurantsObj.get(restaurantId);


}

async function getAll(restaurantId) {
    let getRestaurantData = await getIDWithoutString(restaurantId);
    if (getRestaurantData.reviews.length === 0)
        return []
    if (getRestaurantData.reviews.length > 0)
        return getRestaurantData;
}

const getIDWithoutString = async function getIDWithoutString(restaurantId) {
    if (!restaurantId) throw "Please provide an Id to search"
    if (typeof restaurantId !== "string") throw "Id must be provided in string"
    if (!ObjectId.isValid(restaurantId.trim())) throw "Provide a valid object Id"
    const restaurantCollection = await restaurants();
    var restaurantDataByID = await restaurantCollection.findOne({ _id: ObjectId(restaurantId.trim()) });
    if (restaurantDataByID === null) throw "Reviews does not exist for the given restaurant id ${restaurantId.trim()}"
    return restaurantDataByID;
}

async function get(reviewId) {
    if (!reviewId) throw "Please provide an Id to search"
    if (typeof reviewId !== "string") throw "Id must be provided in string"
    if (!ObjectId.isValid(reviewId.trim())) throw "Provide a valid object Id"
    const restaurantCollection = await restaurants();
    let getRestaurantAndAllReview = await restaurantCollection.find({ 'reviews._id': ObjectId(reviewId) }).toArray();
    if (getRestaurantAndAllReview.length === 0) throw "Reviews does not exist for the given id ${reviewId}."
    let reviewByID = getRestaurantAndAllReview[0].reviews.filter(function (review) {
        return review._id == reviewId;
    });
    return reviewByID[0];
}

async function remove(reviewId) {
    if (!reviewId) throw "Please provide an Id to search"
    if (typeof reviewId !== "string") throw "Id must be provided in string"
    if (!ObjectId.isValid(reviewId.trim())) throw "Provide a valid object Id"
    const restaurantCollection = await restaurants();
    let idToReturn = { reviewId: reviewId, deleted: true };

   
    let resId = await restaurantCollection.findOne({"reviews._id" :  new ObjectId(reviewId)});
    
    let deletedReviewInfo = await restaurantCollection.update({}, { $pull: { reviews: { _id: new ObjectId(reviewId) } } }, { multi: false });
    if (deletedReviewInfo.modifiedCount === 0) throw "Unable to delete review for the given ID ${id}."
    

   var reviews_ =await getAll(String(resId._id))
   if(reviews_.length==0) return idToReturn;
    let count = 0
    for ( let review_ of reviews_.reviews){
        count = count + review_.rating
    }
    await restaurantCollection.updateOne({_id: resId._id},{$set:{overallRating : Number((count/(reviews_.reviews).length).toFixed(2))}});
        if (deletedReviewInfo.modifiedCount === 1)
        return idToReturn;

}
const verifyReviewDate = async function verifyReviewDate(dateReview) {
    const regExpression = /^(\d\d?)\/(\d\d?)\/(\d{4})$/;
    let revDate = dateReview.match(regExpression);
    let isValid = revDate;
    let maxDate = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (revDate) {
        const month = parseInt(revDate[1]);
        const date = parseInt(revDate[2]);
        const year = parseInt(revDate[3]);
        isValid = month <= 12 && month > 0;
        isValid &= date <= maxDate[month] && date > 0;
        const leapYear = (year % 400 == 0)
            || (year % 4 == 0 && year % 100 != 0);
        isValid &= month != 2 || leapYear || date <= 28;
    }

    return isValid
}


module.exports = {
    create,
    getAll,
    get,
    remove,
    verifyReviewDate
}