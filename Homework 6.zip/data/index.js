const restaurantsData = require("./restaurants")
const reviewData = require("./reviews")

module.exports = {
   restaurants: restaurantsData,
   reviews: reviewData
}