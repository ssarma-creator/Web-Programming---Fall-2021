const mongoCollections = require('./../config/mongoCollections');
const restaurants = mongoCollections.restaurants;
let { ObjectId } = require('mongodb');

function isObject(object)
{
  return typeof(object) === 'object' && object!==null && !Array.isArray(object);
}

async function create(name, location, phoneNumber, website, priceRange, cuisines,serviceOptions)
{
   if(!name || !location || !phoneNumber || !website || !priceRange || !cuisines  || !serviceOptions) throw "All fields need to have valid values";
   if(typeof(name) !=='string' || typeof(location) !=='string' || typeof(phoneNumber) !=='string' || typeof(website) !=='string' || typeof(priceRange) !=='string' ) throw "All the parameters has to be string";
   if (name.trim().length == 0 || location.trim().length == 0 || phoneNumber.trim().length == 0 || website.trim().length == 0 || priceRange.trim().length == 0) throw "All parameters must not contain blank space."
    let phonenum = /^[0-9]{3}\-[0-9]{3}\-[0-9]{4}/;
    if(!phoneNumber.match(phonenum)) throw "Phone number is not in valid format! please enter in -'###-###-####' format"
    let websites = /^(http:\/\/www\.).{5,}\.(com)/;
    if(!website.match(websites)) throw "Website is not valid! please enter in http://www. followed by any five characters and ends in .com format"
    if(priceRange !== "$"  && priceRange !=="$$" && priceRange !=="$$$" && priceRange !=="$$$$") throw "Price range is not valid";
    if(!Array.isArray(cuisines)) throw "Cuisines is not an Array";
    if (await verifyCuisines(cuisines) == 0 || cuisines.length == 0) throw "Cuisine cannot be blank or atleast one cuisine is required."
    if(!isObject(serviceOptions)) throw "serviceOptions is not an Object";
    if(!serviceOptions.dineIn|| typeof(serviceOptions.dineIn) !== 'boolean' && 
    !serviceOptions.takeOut || typeof(serviceOptions.takeOut) !== 'boolean' &&
    !serviceOptions.delivery || typeof(serviceOptions.delivery) !== 'boolean') throw "The serviceOptions are not available/ valid."
    

    const restaurantCollection = await restaurants();
    let newRestaurant = {
        name: name,
        location: location,
        phoneNumber: phoneNumber,
        website: website,
        priceRange: priceRange,
        cuisines: cuisines,
        overallRating:0,
        serviceOptions: serviceOptions,
        reviews: []
    };
    const insertDetails = await restaurantCollection.insertOne(newRestaurant);
   
    if(insertDetails.insertedCount === 0) throw "Could not add restaurant"
    const newId = insertDetails.insertedId.toString();
    
    const restaur = await this.get(newId);
    
    return restaur;

}

const verifyCuisines = async function verifyCuisines(cuisines) {
    let data = cuisines.filter(cuisinesElement => (!cuisinesElement || typeof cuisinesElement !== "string" || (cuisinesElement.trim()).length == 0));
    if (data.length > 0) {
        return 0;
    } else return 1;
}
async function getAll()
{
    const restaurantCollection = await restaurants();
    let rest =  await restaurantCollection.find({}, {projection:{_id:1, name:1}}).toArray();
    if (rest.length === 0)
        return []
    if (rest.length > 0)
        return rest;
   
}

async function get(id)
{
    if(!id) throw "id parameter is missing/ empty string";
    if(typeof(id) !== "string" || isEmptyString(id)) throw "id is not a string or an empty string"
    if (!ObjectId.isValid(id.trim())) throw 'Please provide a valid objectID.'
    const restaurantCollection = await restaurants();
    const convertedId = ObjectId(id);
    let resta = await restaurantCollection.findOne({_id : convertedId});
    if(resta === null) throw "No restaurant found by the provided ID";
    resta._id = resta._id.toString();
    return resta;
}
function isEmptyString(string)
{
  return string.trim() === "";
}

async function remove(id)
{
    if(!id) throw "id parameter missing/ an empty string";
    if(typeof(id) !== "string" || isEmptyString(id)) throw "id is not a string or an empty string";
    if (!ObjectId.isValid(id.trim())) throw "Please provide a valid objectID."
    const restaurantCollection = await restaurants();
    const restaurant = await get(id);
    const deleteId = await restaurantCollection.deleteOne({_id: new ObjectId(id)});
    if(deleteId.deletedCount === 0) throw "Removal was not succesfull/No restaurant found by the provided ID";
    if (deleteId.deletedCount === 1)
        return {"restaurantId": id, "deleted": true}
        
        
}
async function update(id, name, location, phoneNumber, website, priceRange, cuisines, serviceOptions) {
    if(!name || !location || !phoneNumber || !website || !priceRange || !cuisines  || !serviceOptions) throw "All fields need to have valid values";
    if(typeof(name) !=='string' || typeof(location) !=='string' || typeof(phoneNumber) !=='string' || typeof(website) !=='string' || typeof(priceRange) !=='string' ) throw "All the parameters has to be string";
    if (name.trim().length == 0 || location.trim().length == 0 || phoneNumber.trim().length == 0 || website.trim().length == 0 || priceRange.trim().length == 0) throw "All parameters must not contain blank space."
    let phonenum = /^[0-9]{3}\-[0-9]{3}\-[0-9]{4}/;
    if(!phoneNumber.match(phonenum)) throw "Phone number is not in valid format! please enter in -'###-###-####' format"
    let websites = /^(http:\/\/www\.).{5,}\.(com)/;
    if(!website.match(websites)) throw "Website is not valid! please enter in http://www. followed by any five characters and ends in .com format"
   
    if(priceRange !== "$"  && priceRange !=="$$" && priceRange !=="$$$" && priceRange !=="$$$$") throw "Price range is not valid";
    if(!Array.isArray(cuisines)) throw "Cuisines is not an Array";
    if (await verifyCuisines(cuisines) == 0 || cuisines.length == 0) throw "Cuisine cannot be blank or atleast one cuisine is required."
    if(!isObject(serviceOptions)) throw "serviceOptions is not an Object";
    if(!serviceOptions.dineIn|| typeof(serviceOptions.dineIn) !== 'boolean' && 
     !serviceOptions.takeOut || typeof(serviceOptions.takeOut) !== 'boolean' &&
    !serviceOptions.delivery || typeof(serviceOptions.delivery) !== 'boolean') throw "The serviceOptions are not available/ valid."
    if (!id) throw "Please provide an ID to search"
    if (typeof id !== "string") throw "Id must be provided in string"
    if (!ObjectId.isValid(id.trim())) throw "Provide a valid object Id"
    const restaurantCollection = await restaurants();
    let restaurantID = {_id: new ObjectId(id)};
    
    let restaurantsValue = { $set: {name, location, phoneNumber, website, priceRange, cuisines, serviceOptions} };
    let insertDetails = await restaurantCollection.updateOne(restaurantID,restaurantsValue );
    
    if (insertDetails.modifiedCount === 0) throw "No changes made. So unable to update the restaurant"
    if (insertDetails.modifiedCount === 1)
        return get(id);
}



module.exports = {
    create,
    getAll,
    get,
    remove,
    update,
    verifyCuisines,
}
