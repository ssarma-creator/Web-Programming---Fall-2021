const express = require('express');
const router = express.Router();
const data = require('./../data');
const restaurantsData = data.restaurants;
const reviewsData = data.reviews;
const { ObjectId } = require("mongodb");
function isObject(object)
{
  return typeof(object) === 'object' && object!==null && !Array.isArray(object);
}
router.get('/', async (req, res) => {
    try {
        let restaurants = await restaurantsData.getAll();
        res.json(restaurants);
    } catch (e) {
        res.status(e.statusCode ? e.statusCode : 500).json({
            error: e.message ?  e.message: "Something went wrong!!"
        });
    }
});
router.post('/', async (req, res) => {
    let {name, location, phoneNumber, website, priceRange, cuisines, serviceOptions} = req.body;
 
    try {
        try {
            if(!name || !location || !phoneNumber || !website || !priceRange || !cuisines || !serviceOptions) throw "All fields need to have valid values";
            if(typeof(name) !=='string' || typeof(location) !=='string' || typeof(phoneNumber) !=='string' || typeof(website) !=='string' || typeof(priceRange) !=='string' ) throw "All the parameters has to be string";
            if (name.trim().length == 0 || location.trim().length == 0 || phoneNumber.trim().length == 0 || website.trim().length == 0 || priceRange.trim().length == 0) throw "All parameters must not contain blank space."
            let phonenum = /^[0-9]{3}\-[0-9]{3}\-[0-9]{4}/;
            if(!phoneNumber.match(phonenum)) throw "Phone number is not in valid format! please enter in -'###-###-####' format"
            let websites = /^(http:\/\/www\.).{5,}\.(com)/;
            if(!website.match(websites)) throw "Website is not valid! please enter in http://www. followed by any five characters and ends in .com format"
            if(priceRange !== "$"  && priceRange !=="$$" && priceRange !=="$$$" && priceRange !=="$$$$") throw "Price range is not valid";
            if(!Array.isArray(cuisines)) throw "Cuisines is not an Array";
            if (await restaurantsData.verifyCuisines(cuisines) == 0 || cuisines.length == 0) throw "Cuisine cannot be blank or atleast one cuisine is required."
            if(!isObject(serviceOptions)) throw "serviceOptions is not an Object";
             if(!serviceOptions.dineIn|| typeof(serviceOptions.dineIn) !== 'boolean' && 
             !serviceOptions.takeOut || typeof(serviceOptions.takeOut) !== 'boolean' &&
             !serviceOptions.delivery || typeof(serviceOptions.delivery) !== 'boolean') throw "The serviceOptions are not available/ valid."
             if (serviceOptions.dineIn === undefined || serviceOptions.takeOut === undefined || serviceOptions.delivery === undefined) throw `author.authorFirstName AND author.authorLastName should be provided.`
        } catch (e) {
        
            res.status(400).json({ error: e });
            return;
        }

        
        const newRestaurant = await restaurantsData.create(name, location, phoneNumber, website,priceRange,cuisines,serviceOptions);
        res.json(newRestaurant);
    } catch (e) {
        
        res.status(500).json({ error: e });
    }
});
router.get('/:id', async (req, res) => {
    try {
        try {
            if (!req.params.id) throw "Please provide an Id to search"
            if (typeof req.params.id !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.id.trim())) throw "Provide a valid object Id"
        } catch (e) {
            res.status(400).json({ error: e });
            return;
        }
        const get = await restaurantsData.get(req.params.id);
        res.json(get);
    } catch (e) {
        res.status(404).json({ error: e });
    }
});
router.put('/:id', async (req, res) => {
    let {name, location, phoneNumber, website, priceRange, cuisines, serviceOptions} = req.body;
    try {
        try {
            
            if(!name || !location || !phoneNumber || !website || !priceRange || !cuisines || !serviceOptions) throw "All fields need to have valid values";
            if(typeof(name) !=='string' || typeof(location) !=='string' || typeof(phoneNumber) !=='string' || typeof(website) !=='string' || typeof(priceRange) !=='string' ) throw "All the parameters has to be string";
            if (name.trim().length == 0 || location.trim().length == 0 || phoneNumber.trim().length == 0 || website.trim().length == 0 || priceRange.trim().length == 0) throw "All parameters must not contain blank space."
            let phonenum = /^[0-9]{3}\-[0-9]{3}\-[0-9]{4}/;
            if(!phoneNumber.match(phonenum)) throw "Phone number is not in valid format! please enter in -'###-###-####' format"
            let websites = /^(http:\/\/www\.).{5,}\.(com)/;
            if(!website.match(websites)) throw "Website is not valid! please enter in http://www. followed by any five characters and ends in .com format"
            if(priceRange !== "$"  && priceRange !=="$$" && priceRange !=="$$$" && priceRange !=="$$$$") throw "Price range is not valid";
            if(!Array.isArray(cuisines)) throw "Cuisines is not an Array";
            if (await restaurantsData.verifyCuisines(cuisines) == 0 || cuisines.length == 0) throw "Cuisine cannot be blank or atleast one cuisine is required."
            if(!isObject(serviceOptions)) throw "serviceOptions is not an Object";
            if(!serviceOptions.dineIn|| typeof(serviceOptions.dineIn) !== 'boolean' && 
            !serviceOptions.takeOut || typeof(serviceOptions.takeOut) !== 'boolean' &&
            !serviceOptions.delivery || typeof(serviceOptions.delivery) !== 'boolean') throw "The serviceOptions are not available/ valid."
  } catch (e) {
            res.status(400).json({ error: e });
            return;
        }

        try {
            await restaurantsData.get(req.params.id);
        } catch (e) {
            res.status(404).json({ error: e });
            return;
        }

        let getAllReviewOfARestaurant = await reviewsData.getAll(req.params.id);
        const newRestaurant = await restaurantsData.update(req.params.id, name, location, phoneNumber, website, priceRange, cuisines, serviceOptions, getAllReviewOfARestaurant);
        res.json(newRestaurant);
    } catch (e) {
    
        res.status(400).json({ error: e });
    }
});


router.delete('/:id', async (req, res) => {
    try {
        try {
            if (!req.params.id) throw "Please provide an Id to search"
            if (typeof req.params.id !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.id.trim())) throw "Provide a valid object Id"
        } catch (e) {
            res.status(400).json({ error: e });
            return;
        }

        try {
            await restaurantsData.get(req.params.id);
        } catch (e) {
            res.status(404).json({ error: e });
            return;
        }

        const deleteID = await restaurantsData.remove(req.params.id);
        res.json(deleteID);
    } catch (e) {
        res.status(500).json({ error: e });
    }
});
    
module.exports = router;


