const express = require('express');
const router = express.Router();
const data = require("../data");
const reviewsData = data.reviews;
const restaurantsData = data.restaurants;
const { ObjectId } = require("mongodb");

router.get('/:restaurantId', async (req, res) => {
    try {
        try {
            if (!req.params.restaurantId) throw "Please provide an Id to search"
            if (typeof req.params.restaurantId !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.restaurantId.trim())) throw "Provide a valid object Id"
        } catch (e) {
            res.status(400).json({ error: e });
            return;
        }
        let getReviewsData = await reviewsData.getAll(req.params.restaurantId);
        res.json(getReviewsData);
    } catch (e) {
        res.status(404).json({ error: e });
    }
});

router.post('/:restaurantId', async (req, res) => {
    let {title, reviewer, rating, dateOfReview, review} = req.body;
    try {
        try {
            let verifyReqBody = Object.keys(req.body);
            keyAndLengthOfBody = verifyReqBody.filter(value => (value != "title" && value != "reviewer" && value != "rating" && value != "dateOfReview" && value != "review"));
            if (keyAndLengthOfBody.length > 0) throw "You must not provide extra elements in the request body."
            if (!title || !reviewer || !rating || !dateOfReview || !review) throw "All fields need to have valid values."
            if (typeof title !== "string" || typeof reviewer !== "string" || typeof rating !== "number" || typeof dateOfReview !== "string" || typeof review !== "string") throw "All the fields must be provided in string and rating in number"
            if (title.trim().length == 0 || reviewer.trim().length == 0 || dateOfReview.trim().length == 0 || review.trim().length == 0) throw "All parameters must not contain blank space."
            if(!Number(rating)) throw "The rating should be a number only"
            if (rating < 1 || rating > 5) throw "The rating should be between 1 to 5 only."
            if (await reviewsData.verifyReviewDate(dateOfReview) !== 1) throw "The dateOfReview should be in MM/DD/YYYY format."
            if (!req.params.restaurantId) throw "Please provide an Id to search"
            if (typeof req.params.restaurantId !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.restaurantId.trim())) throw "Provide a valid object Id"
            await restaurantsData.get(req.params.restaurantId)
        } catch (e) {
          
            res.status(400).json({ error: e });
            return;
        }

        const newReview = await reviewsData.create(req.params.restaurantId,title, reviewer, rating, dateOfReview, review);
        res.json(newReview);
    } catch (e) {
        
        res.status(400).json({ error: e });
    }
});


router.get('/review/:id', async (req, res) => {
    try {
        try {
            if (!req.params.id) throw "Please provide an Id to search"
            if (typeof req.params.id !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.id.trim())) throw "Provide a valid object Id"
        } catch (e) {
            res.status(400).json({ error: e });
            return;
        }
        let getReviewIDData = await reviewsData.get(req.params.id);
        res.json(getReviewIDData);
    } catch (e) {
       
        res.status(404).json({ error: e });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        try {
            if (!req.params.id) throw "Please provide an Id to search"
            if (typeof req.params.id !== "string") throw "Id must be provided in string"
            if (!ObjectId.isValid(req.params.id.trim())) throw "Provide a valid object Id"
        } catch (e) {
            res.status(400).json({ error: e });
            return;
        }

        try {
            await reviewsData.get(req.params.id);
        } catch (e) {
            res.status(404).json({ error: e });
            return;
        }

        const deleteID = await reviewsData.remove(req.params.id);
        res.json(deleteID);
    } catch (e) {
        res.status(500).json({ error: e });
    }
});

module.exports = router;