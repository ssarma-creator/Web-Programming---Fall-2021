const questionOne = function questionOne(arr) {
    // Implement question 1 here
    if(arr == null)
    {
        return {};
    }
    else
    {
        let primeObj ={};
        arr.forEach((element) => {
            const x = Math.abs(element*element - 7);
            primeObj[x] = isPrime(x);
    });
    return primeObj;
    }
}
const isPrime = function isPrime(element) {
    if(element<=1)
    {
        return false;
    }
    else if(element===2)
    {
        return true;
    }
    else{
    for(var i= 2;i<element;i++)
    {
        if(element%i == 0)
        {
            return false;
        }
    }
    return true;
}
}

const questionTwo = function questionTwo(arr) { 
    // Implement question 2 here

    if(arr == null) {
        return{};
    }else{
        var uniqueArray = [];
        for(j=0;j< arr.length;j++){
            if(findIndex(uniqueArray, arr[j]) === -1){
                uniqueArray.push(arr[j]);
            }
        }
        return uniqueArray;
    }
}

function findIndex(uniqueArray, value){
    for(i=0; i < uniqueArray.length;i++){
        if (uniqueArray[i] === value) return i;
    }
    return -1;
}

const questionThree = function questionThree(arr) {
    // Implement question 3 here
    let map = new Map();
  
    for (i=0;i<arr.length;i++){
         key = sortString(arr[i]);
         if(!map.get(key)) {
             map.set(key,new Set());
          }
           map.get(key).add(arr[i]);
    }
    map.forEach( (value,key,map)=> {
      if(value.size==1) {
        map.delete(key);
      }else{
        map.set(key,Array.from(value));
      }
    });
    return Object.fromEntries(map);
  
  }
  
  function sortString (string){
    let splitString  = string.split('');
    let sorted = splitString.sort();
    return sorted.join('');
  }

  const questionFour = function questionFour(num1, num2, num3) {
    // Implement question 4 here
    let factAdd = fact(num1) + fact(num2) + fact(num3);
    let average = (num1 + num2 + num3)/3;
    return Math.floor(factAdd/average);
    }
    
    function fact(num) {
        if(num==0) {
          return 1;
        }
        return num * fact(num - 1);
      }
module.exports = {
    firstName: "Sudarshana", 
    lastName: "Sarma", 
    studentId: "10469063",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};