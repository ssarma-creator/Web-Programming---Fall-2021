const axios = require ('axios')
const express = require("express")
const router = express.Router()

router.get("/", async (req,res) => {
    try{
        const peopleList = await getPeople()
        res.json(peopleList);
    }
    catch(e){
        res.status(500).send();
    }
    }
);

router.get("/:id", async (req,res) => {

    try{
        const peopleByID = await getPeoplebyId(req.params.id)
        res.json(peopleByID);
    }
    catch(e){
        console.log(e);
        res.status(404).json({message:e});
    }
    }
);

async function getPeople()
{
    const {data} = await axios.get('https://gist.githubusercontent.com/graffixnyc/a1196cbf008e85a8e808dc60d4db7261/raw/9fd0d1a4d7846b19e52ab3551339c5b0b37cac71/people.json')
    return data;
}

async function getPeoplebyId(id)
{
    
    if(!id) throw "Id not entered"
    if (typeof (id) != 'string' ) throw "Please enter a valid Id";
    if(Number(id)) throw "Integer value not allowed";
    if (id.trim() === "") throw "The input contains white spaces";
    try{
        const data  = await getPeople();
        let res = data.find(ele => ele.id == id);
        if(!res || res.length==0) throw "Person with the provided Id not found";
        return res;
    }


    catch(e)
    {
        throw "Person with the provided Id not found"
    }
}

module.exports = router;



