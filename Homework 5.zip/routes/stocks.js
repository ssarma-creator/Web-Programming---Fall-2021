const axios = require ('axios')
const express = require("express")
const router = express.Router()


router.get("/", async (req,res) => {
    try{
        const stocksList = await getStocks()
        res.json(stocksList);
    }
    catch(e){
        res.status(500).send();
    }
    }
);

router.get("/:id", async (req,res) => {

    try{
        const stocksByID = await getStocksbyId(req.params.id)
        res.json(stocksByID);
    }
    catch(e){
        res.status(404).json({message:e});
    }
    }
);

async function getStocks()
{
    const {data} = await axios.get('https://gist.githubusercontent.com/graffixnyc/8c363d85e61863ac044097c0d199dbcc/raw/7d79752a9342ac97e4953bce23db0388a39642bf/stocks.json')
    return data;
}

async function getStocksbyId(id)
{
    if(!id) throw "Id not entered"
    if (typeof (id) != 'string') throw "Please enter a valid Id";
    if(Number(id)) throw "Integer value not allowed";
    if (id.trim() === "") throw "The input contains just white spaces";
    
    try{
        const data  = await getStocks();
        let result = data.find(ele => ele.id == id);
        if(!result || result.length==0) throw "Stock with the provided Id not found";
        return result;
    }
    catch(e)
    {   
        throw "Stock with the provided Id not found"
    }
}

module.exports = router;
