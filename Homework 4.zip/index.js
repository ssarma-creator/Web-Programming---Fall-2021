  const restaurants = require('./data/restaurants');

  async function main() {
   //  1. Create a restaurant of your choice.

    try {
        
            let name = "The Saffron Lounge";
            let location = "New York City, New York";
            let phoneNumber= "123-456-7890";
            let website= "http://www.saffronlounge.com";
            let priceRange= "$$$$";
            let cuisines=["Cuban", "Italian"];
            let overallRating = 14;
            let serviceOptions = {dineIn:true, takeOut: true, delivery: false}

        let addRestaurant = await restaurants.create(name, location, phoneNumber, website, priceRange, cuisines, overallRating, serviceOptions);
        console.log(addRestaurant);
    } catch (err) {
        console.log(err);
    }

    //2. Log the newly created restaurant. (Just that restaurant, not all restaurants)
    try {
        let restaurantList = await restaurants.get("6163bb8718dfd800ce3ca878");
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }

    //3. Create another restaurant of your choice
    try {
        let name =  "Felice Columbus";
        let location =  "Union City, New Jersey";
        let phoneNumber =  "212-931-1150";
        let website =  "http://www.felicecolumbus.com";
        let priceRange =  "$$";
        let cuisines = ["Dominic Republic","Columbia"];
        let overallRating =  2;
        let serviceOptions = {dineIn: true, takeOut :  true, delivery :  false};
        let addRestaurant = await restaurants.create(name, location, phoneNumber, website, priceRange, cuisines, overallRating, serviceOptions);
        console.log(addRestaurant);
    } catch (err) {
        console.log(err);
    }

    //4. Query all restaurants, and log them all
    try {
        let restaurantList = await restaurants.getAll();
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }

    //5. Create the 3rd restaurant of your choice.
    try {
        
        let name= "JinesCafe";
        let location= "Jersey City, New Jersey";
        let phoneNumber= "212-931-3120";
        let website="http://www.jinescafe.com";
        let priceRange="$$$";
        let cuisines=["Italian"];
        let overallRating= 4;
        let serviceOptions={dineIn: true, takeOut: true, delivery: false};
        let addRestaurant = await restaurants.create(name, location, phoneNumber, website, priceRange, cuisines, overallRating, serviceOptions);
        console.log(addRestaurant);
    } catch (err) {
        console.log(err);
    }
    
    //6. Log the newly created 3rd restaurant. (Just that restaurant, not all restaurants)
    try {
        let restaurantList = await restaurants.get("6164e04c2082320d6e633108");
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }

  //  7. Rename the first restaurant website
    try {
        let updatedRestaurant = await restaurants.rename("6163bb8718dfd800ce3ca878", "http://www.saffronlounge2.com");
        if (updatedRestaurant) console.log(updatedRestaurant);
    } catch (err) {
        console.log(err);
    }

    //8. Log the first restaurant with the updated website. 
    try {
        let restaurantList = await restaurants.get("6163bb8718dfd800ce3ca878");
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }

     //9. Remove the second restaurant you created.
    try {
        let removedRestaurant= await restaurants.remove("6164e745b5acc1ae9a05c700");
        if (removedRestaurant) console.log(removedRestaurant+" has been removed..");
    } catch (err) {
        console.log(err);
    }

    //10. Query all restaurants, and log them all
    try {
        let restaurantList = await restaurants.getAll();
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }

    //11. Try to create a restaurant with bad input parameters to make sure it throws errors.
    try {
        
            let name= "JinesCafe";
            let location="Jersey City, New Jersey";
            let phoneNumber= "212-931-3120";
            let website= "http://www.jinescafe.com";
            let priceRange= "$$$";
            let cuisines=["Italian","     "];
            let overallRating= 4;
            let serviceOptions={dineIn: true, takeOut: true, delivery: false};
        
        let addRestaurant = await restaurants.create(name, location, phoneNumber, website, priceRange, cuisines, overallRating, serviceOptions);
        console.log(addRestaurant);
    } catch (err) {
        console.log(err);
    }

    //12. Try to remove a restaurant that does not exist to make sure it throws errors.
    try {
        let removedRestaurant = await restaurants.remove("6163bb8718dfd800ce3ca878");
        if (removedRestaurant) console.log(removedRestaurant);
    } catch (err) {
        console.log(err);
    }
    
    //13.Try to rename a restaurant that does not exist to make sure it throws errors.
    try {
        let updatedRestaurant = await restaurants.rename("60401bdcc7b260395cbb44e4", "The Manor");
        if (updatedRestaurant) console.log(updatedRestaurant);
    } catch (err) {
        console.log(err);
    }

//    14. Try to rename a restaurant passing in invalid data for the parameter to make sure it throws errors.
    try {
        let updatedRestaurant = await restaurants.rename("6163bb8718dfd800ce3ca988", "http://www.saffronlounge2.com");
        console.log(updatedRestaurant);
    } catch (err) {
        console.log(err);
    }

    //15. Try getting a restaurant by ID that does not exist to make sure it throws errors.
    try {
        let restaurantList = await restaurants.get("60401bdcc7b260395cbb44e4");
        console.log(restaurantList);
    } catch (err) {
        console.log(err);
    }


}
  
   main();