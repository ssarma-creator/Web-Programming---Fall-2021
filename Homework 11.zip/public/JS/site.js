$(document).ready(function () {
    $('#showList').hide();
    $('#show').hide();
    $('#homeLink').hide();
    $('#siteError').hide();
    $("#search_term").focus();
    var request = $.ajax({
        url: "http://api.tvmaze.com/shows",
        method: "GET",
        dataType: "json"
    });
    request.done(function (showsData) {
        if (showsData && showsData.length > 0) {
            $.each(showsData, function (index) {
                $("#showList").append($("<li>", {}).append($("<a>", { href: showsData[index]._links.self.href }).text(showsData[index].name)));
            });
            $('#showList').show();
        } else
            $("#siteError").text("Shows not found!!").show();
    });

    request.fail(function (jqXHR, textStatus) {
        $("#siteError").text("Failed to load shows, please try after sometime.").show();
    });
});

$(document).on('submit', '.searchClassForm', function (event) {
    $('#show').hide();
    $('#siteError').hide();
    $('#showList').empty()
    event.preventDefault();
    let searchTerm = $("#search_term").val();
    if (!searchTerm || searchTerm.trim() === "") {
        $("#errorSpan").text("Input must not be left blank or just empty spaces!!").show();
        $("#showList").hide();
        $("#show").hide();
        $("#search_term").focus();
        $('#siteError').hide();
        return
    }
    var request = $.ajax({
        url: "http://api.tvmaze.com/search/shows?q='" + searchTerm + "'",
        method: "GET",
        dataType: "json"
    });
    request.done(function (showsData) {
        if (showsData && showsData.length > 0) {
            $("#searchForm").trigger('reset')
            $("#search_term").focus();
            $('#showList').show()
            $("#errorSpan").hide();
            $('#homeLink').show();
            $.each(showsData, function (index) {
                $("#showList").append($("<li>", {}).append($("<a>", { href: showsData[index].show._links.self.href }).text(showsData[index].show.name)));
            });
        } else {
            $("#siteError").text("Shows not found!!").show();
        }
    });

    request.fail(function (jqXHR, textStatus) {
        $("#siteError").text("Failed to load shows, please try after sometime.").show();
    });
});

$('#showList').on('click', 'li', function (event) {
    $('#siteError').hide();
    $('#showList').hide()
    $('#show').empty()
    $("#search_term").focus();
    event.preventDefault();
    var request = $.ajax({
        url: $(this).find('a').attr("href"),
        method: "GET",
        dataType: "json"
    });

    request.done(function (showsData) {
        if (showsData) {
            let showDetails = `<h1>${showsData.name ? showsData.name : "N/A"}</h1>
            <img alt="${showsData.name}" src="${showsData.image ? showsData.image.medium : './public/image/no_image.jpeg'}" />
            <dl id="showsLanguageID">
              <dt>Language</dt>
              <dd>${showsData.language ? showsData.language : "N/A"}</dd>
              <dt>Genres</dt>
              <dd>
                <ul>  
                <li>
                ${$(document).ready(function () {
                if (showsData.genres.length === 0) {
                    $("ul").append('<li>N/A</li>');
                } else {
                    $.each(showsData.genres, function (index, value) {
                        $(document).ready(function () {
                            $("ul").append('<li>' + showsData.genres[index] + '</li>');
                        });

                    })
                }
            })}
                </ul>
                </li>
              </dd>
              <dt>Average Rating</dt>
              <dd>${showsData.rating.average ? showsData.rating.average : "N/A"}</dd>
              <dt>Network</dt>
              <dd>${showsData.network ? showsData.network.name : "N/A"}</dd>
              <dt>Summary</dt>
              <dd>${showsData.summary ? showsData.summary : "N/A"}</dd>
            </dl>`
            $(document).ready(function () {
                $('#showsLanguageID ul > li').eq(0).hide();
            });

            $("#show").append(showDetails);
            $('#show').show()
            $('#homeLink').show();
        } else {
            $("#siteError").text("Shows not found!!").show();
        }
    });

    
    
    request.fail(function (jqXHR, textStatus) {
        $("#siteError").text("Failed to load shows, please try after sometime.").show();
    });
});
